﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnlogin = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbpassword = New System.Windows.Forms.TextBox()
        Me.tbusername = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnbooking = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btn_announcements = New System.Windows.Forms.Button()
        Me.btnshutdown = New System.Windows.Forms.Button()
        Me.btncredits = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnlogin)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.tbpassword)
        Me.Panel1.Controls.Add(Me.tbusername)
        Me.Panel1.Location = New System.Drawing.Point(39, 116)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(302, 181)
        Me.Panel1.TabIndex = 0
        '
        'btnlogin
        '
        Me.btnlogin.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.btnlogin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnlogin.Font = New System.Drawing.Font("SimSun-ExtB", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnlogin.Location = New System.Drawing.Point(104, 132)
        Me.btnlogin.Name = "btnlogin"
        Me.btnlogin.Size = New System.Drawing.Size(94, 29)
        Me.btnlogin.TabIndex = 3
        Me.btnlogin.Text = "Log-In"
        Me.btnlogin.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(15, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 15)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(15, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 15)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Username:"
        '
        'tbpassword
        '
        Me.tbpassword.Location = New System.Drawing.Point(131, 84)
        Me.tbpassword.Name = "tbpassword"
        Me.tbpassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.tbpassword.Size = New System.Drawing.Size(158, 27)
        Me.tbpassword.TabIndex = 4
        '
        'tbusername
        '
        Me.tbusername.Location = New System.Drawing.Point(131, 41)
        Me.tbusername.Name = "tbusername"
        Me.tbusername.Size = New System.Drawing.Size(158, 27)
        Me.tbusername.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.Location = New System.Drawing.Point(39, 34)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(302, 76)
        Me.Panel2.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnbooking)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Location = New System.Drawing.Point(39, 303)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(302, 104)
        Me.Panel3.TabIndex = 2
        '
        'btnbooking
        '
        Me.btnbooking.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.btnbooking.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnbooking.Font = New System.Drawing.Font("SimSun-ExtB", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.btnbooking.Location = New System.Drawing.Point(104, 53)
        Me.btnbooking.Name = "btnbooking"
        Me.btnbooking.Size = New System.Drawing.Size(94, 29)
        Me.btnbooking.TabIndex = 4
        Me.btnbooking.Text = "Booking"
        Me.btnbooking.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("SimSun", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(12, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(287, 26)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Are you a guest and want to book a " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "reservation? Click Here:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label4.Font = New System.Drawing.Font("SimSun", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(-2, 511)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(290, 10)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Frontend design by Prynze Reyes, All rights reserved 2022"
        '
        'btn_announcements
        '
        Me.btn_announcements.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btn_announcements.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_announcements.Font = New System.Drawing.Font("SimSun", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.btn_announcements.Location = New System.Drawing.Point(39, 413)
        Me.btn_announcements.Name = "btn_announcements"
        Me.btn_announcements.Size = New System.Drawing.Size(302, 63)
        Me.btn_announcements.TabIndex = 6
        Me.btn_announcements.Text = "Announcements"
        Me.btn_announcements.UseVisualStyleBackColor = False
        '
        'btnshutdown
        '
        Me.btnshutdown.BackColor = System.Drawing.Color.RosyBrown
        Me.btnshutdown.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnshutdown.Location = New System.Drawing.Point(348, 492)
        Me.btnshutdown.Name = "btnshutdown"
        Me.btnshutdown.Size = New System.Drawing.Size(37, 29)
        Me.btnshutdown.TabIndex = 7
        Me.btnshutdown.Text = "⛔"
        Me.btnshutdown.UseVisualStyleBackColor = False
        '
        'btncredits
        '
        Me.btncredits.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btncredits.Font = New System.Drawing.Font("SimSun", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.btncredits.ForeColor = System.Drawing.Color.Green
        Me.btncredits.Location = New System.Drawing.Point(160, 482)
        Me.btncredits.Name = "btncredits"
        Me.btncredits.Size = New System.Drawing.Size(77, 22)
        Me.btncredits.TabIndex = 8
        Me.btncredits.Text = "Credits"
        Me.btncredits.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnlogin
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(382, 520)
        Me.ControlBox = False
        Me.Controls.Add(Me.btncredits)
        Me.Controls.Add(Me.btnshutdown)
        Me.Controls.Add(Me.btn_announcements)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(400, 567)
        Me.MinimumSize = New System.Drawing.Size(400, 567)
        Me.Name = "Form1"
        Me.Text = "CUMIN Log-in"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents tbpassword As TextBox
    Friend WithEvents tbusername As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnlogin As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents btnbooking As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btn_announcements As Button
    Friend WithEvents btnshutdown As Button
    Friend WithEvents btncredits As Button
End Class
