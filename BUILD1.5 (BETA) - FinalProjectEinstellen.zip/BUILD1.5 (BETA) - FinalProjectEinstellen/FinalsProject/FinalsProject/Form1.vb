﻿Public Class Form1


    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        If LCase(tbusername.Text) = "admin" And LCase(tbpassword.Text) = "admin" Then
            MessageBox.Show("Welcome back, admin. Glad to see you working.", "Log-in",
 MessageBoxButtons.OK, MessageBoxIcon.Information)
            tbusername.Clear()
            tbpassword.Clear()
            Me.Hide()
            AdminPanel.Show()

        ElseIf LCase(tbusername.Text) = "hotelier" And LCase(tbpassword.Text) = "cuminspice" Then
            MessageBox.Show("Welcome back, Sir Cumin. It is rather rare to see you on the field.", "Log-in",
 MessageBoxButtons.OK, MessageBoxIcon.Information)
            tbusername.Clear()
            tbpassword.Clear()
            Me.Hide()
            OwnerCumin.Show()


        Else
            MessageBox.Show("Username or Password is Incorrect. Please try again.", "Log-in",
 MessageBoxButtons.OK, MessageBoxIcon.Error)
            tbusername.Clear()
            tbpassword.Clear()

        End If
    End Sub

    Private Sub btnbooking_Click(sender As Object, e As EventArgs) Handles btnbooking.Click
        Me.Hide()
        Booking.Show()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Credits.Show()
        Me.Hide()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_announcements_Click(sender As Object, e As EventArgs) Handles btn_announcements.Click
        Announcements.Show()
        Me.Hide()
    End Sub

    Private Sub btnshutdown_Click(sender As Object, e As EventArgs) Handles btnshutdown.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btncredits.Click
        Credits.Show()
        Me.Hide()
    End Sub
End Class
