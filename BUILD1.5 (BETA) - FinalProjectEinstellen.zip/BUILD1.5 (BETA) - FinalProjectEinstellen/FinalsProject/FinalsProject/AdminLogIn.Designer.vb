﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminPanel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminPanel))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btndisplaydata = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btninput = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbcheckout = New System.Windows.Forms.TextBox()
        Me.tbcheckin = New System.Windows.Forms.TextBox()
        Me.tbroomtype = New System.Windows.Forms.TextBox()
        Me.tbclientname = New System.Windows.Forms.TextBox()
        Me.tbclientid = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lbldatetime = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnhelp = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel1.Controls.Add(Me.btndisplaydata)
        Me.Panel1.Controls.Add(Me.btnclear)
        Me.Panel1.Controls.Add(Me.btninput)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.tbcheckout)
        Me.Panel1.Controls.Add(Me.tbcheckin)
        Me.Panel1.Controls.Add(Me.tbroomtype)
        Me.Panel1.Controls.Add(Me.tbclientname)
        Me.Panel1.Controls.Add(Me.tbclientid)
        Me.Panel1.Location = New System.Drawing.Point(12, 112)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(305, 329)
        Me.Panel1.TabIndex = 0
        '
        'btndisplaydata
        '
        Me.btndisplaydata.BackColor = System.Drawing.Color.PaleGreen
        Me.btndisplaydata.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btndisplaydata.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btndisplaydata.Location = New System.Drawing.Point(64, 256)
        Me.btndisplaydata.Name = "btndisplaydata"
        Me.btndisplaydata.Size = New System.Drawing.Size(167, 49)
        Me.btndisplaydata.TabIndex = 12
        Me.btndisplaydata.Text = "Display Data"
        Me.btndisplaydata.UseVisualStyleBackColor = False
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.Color.MistyRose
        Me.btnclear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnclear.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnclear.Location = New System.Drawing.Point(149, 201)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(82, 49)
        Me.btnclear.TabIndex = 11
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'btninput
        '
        Me.btninput.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btninput.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btninput.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btninput.Location = New System.Drawing.Point(64, 201)
        Me.btninput.Name = "btninput"
        Me.btninput.Size = New System.Drawing.Size(79, 49)
        Me.btninput.TabIndex = 10
        Me.btninput.Text = "Input"
        Me.btninput.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(3, 159)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 15)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Check-out"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(3, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 15)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Check-in"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(3, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 15)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Room Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(3, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 15)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Client Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(3, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 15)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Client ID"
        '
        'tbcheckout
        '
        Me.tbcheckout.Location = New System.Drawing.Point(114, 152)
        Me.tbcheckout.Name = "tbcheckout"
        Me.tbcheckout.Size = New System.Drawing.Size(175, 27)
        Me.tbcheckout.TabIndex = 4
        '
        'tbcheckin
        '
        Me.tbcheckin.Location = New System.Drawing.Point(114, 119)
        Me.tbcheckin.Name = "tbcheckin"
        Me.tbcheckin.Size = New System.Drawing.Size(175, 27)
        Me.tbcheckin.TabIndex = 3
        '
        'tbroomtype
        '
        Me.tbroomtype.Location = New System.Drawing.Point(114, 86)
        Me.tbroomtype.Name = "tbroomtype"
        Me.tbroomtype.Size = New System.Drawing.Size(175, 27)
        Me.tbroomtype.TabIndex = 2
        '
        'tbclientname
        '
        Me.tbclientname.Location = New System.Drawing.Point(114, 53)
        Me.tbclientname.Name = "tbclientname"
        Me.tbclientname.Size = New System.Drawing.Size(175, 27)
        Me.tbclientname.TabIndex = 1
        '
        'tbclientid
        '
        Me.tbclientid.Location = New System.Drawing.Point(114, 20)
        Me.tbclientid.Name = "tbclientid"
        Me.tbclientid.Size = New System.Drawing.Size(175, 27)
        Me.tbclientid.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(323, 112)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(534, 329)
        Me.Panel2.TabIndex = 1
        '
        'btnlogout
        '
        Me.btnlogout.BackColor = System.Drawing.Color.MistyRose
        Me.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnlogout.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnlogout.ForeColor = System.Drawing.Color.IndianRed
        Me.btnlogout.Location = New System.Drawing.Point(776, 462)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(94, 29)
        Me.btnlogout.TabIndex = 2
        Me.btnlogout.Text = "Log-out"
        Me.btnlogout.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(12, 24)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(305, 82)
        Me.Button5.TabIndex = 3
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.lbldatetime)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Location = New System.Drawing.Point(607, 24)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(250, 82)
        Me.Panel3.TabIndex = 4
        '
        'lbldatetime
        '
        Me.lbldatetime.AutoSize = True
        Me.lbldatetime.Font = New System.Drawing.Font("SimSun", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lbldatetime.Location = New System.Drawing.Point(13, 31)
        Me.lbldatetime.Name = "lbldatetime"
        Me.lbldatetime.Size = New System.Drawing.Size(138, 17)
        Me.lbldatetime.TabIndex = 0
        Me.lbldatetime.Text = "Date and Time"
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Location = New System.Drawing.Point(3, 13)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(242, 55)
        Me.Panel4.TabIndex = 1
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'btnhelp
        '
        Me.btnhelp.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.btnhelp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnhelp.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnhelp.ForeColor = System.Drawing.SystemColors.Highlight
        Me.btnhelp.Location = New System.Drawing.Point(676, 462)
        Me.btnhelp.Name = "btnhelp"
        Me.btnhelp.Size = New System.Drawing.Size(94, 29)
        Me.btnhelp.TabIndex = 5
        Me.btnhelp.Text = "Help"
        Me.btnhelp.UseVisualStyleBackColor = False
        '
        'AdminPanel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.CancelButton = Me.btnlogout
        Me.ClientSize = New System.Drawing.Size(882, 503)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnhelp)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.btnlogout)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(900, 550)
        Me.Name = "AdminPanel"
        Me.Text = "CUMIN Reservation System"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents tbcheckout As TextBox
    Friend WithEvents tbcheckin As TextBox
    Friend WithEvents tbroomtype As TextBox
    Friend WithEvents tbclientname As TextBox
    Friend WithEvents tbclientid As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btnclear As Button
    Friend WithEvents btninput As Button
    Friend WithEvents btnlogout As Button
    Friend WithEvents btndisplaydata As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents lbldatetime As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel4 As Panel
    Friend WithEvents btnhelp As Button
End Class
