﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Booking
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Booking))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnokay = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnback = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(30, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(425, 258)
        Me.Panel1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Vivaldi", 13.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(99, 220)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(237, 28)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "We look forward to your visit!"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("SimSun", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(71, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(305, 198)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = resources.GetString("Label1.Text")
        '
        'btnokay
        '
        Me.btnokay.BackColor = System.Drawing.Color.PaleGreen
        Me.btnokay.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnokay.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnokay.Location = New System.Drawing.Point(204, 276)
        Me.btnokay.Name = "btnokay"
        Me.btnokay.Size = New System.Drawing.Size(94, 29)
        Me.btnokay.TabIndex = 2
        Me.btnokay.Text = "Okay"
        Me.btnokay.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label3.Font = New System.Drawing.Font("SimSun", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(-3, 343)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(290, 10)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Frontend design by Prynze Reyes, All rights reserved 2022"
        '
        'btnback
        '
        Me.btnback.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnback.Location = New System.Drawing.Point(204, 311)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(94, 29)
        Me.btnback.TabIndex = 4
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = False
        '
        'Booking
        '
        Me.AcceptButton = Me.btnokay
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.CancelButton = Me.btnback
        Me.ClientSize = New System.Drawing.Size(482, 353)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnokay)
        Me.Controls.Add(Me.Panel1)
        Me.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximumSize = New System.Drawing.Size(500, 400)
        Me.Name = "Booking"
        Me.Text = "Booking"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnokay As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents btnback As Button
End Class
