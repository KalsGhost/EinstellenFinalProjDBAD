﻿Public Class AdminPanel



    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        MessageBox.Show("Goodbye.", "Logged out",
 MessageBoxButtons.OK, MessageBoxIcon.Information)
        Form1.Show()
        Me.Hide()
        tbcheckin.Clear()
        tbcheckout.Clear()
        tbclientid.Clear()
        tbclientname.Clear()
        tbroomtype.Clear()

    End Sub

    Private Sub AdminPanel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lbldatetime.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss")
    End Sub

    Private Sub btnhelp_Click(sender As Object, e As EventArgs) Handles btnhelp.Click
        Help.Show()
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        tbcheckin.Clear()
        tbcheckout.Clear()
        tbclientid.Clear()
        tbclientname.Clear()
        tbroomtype.Clear()
    End Sub
End Class