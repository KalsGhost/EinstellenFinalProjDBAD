﻿Public Class Help
    Private Sub btnokay_Click(sender As Object, e As EventArgs) Handles btnokay.Click
        AdminPanel.Show()
        Me.Hide()
    End Sub
End Class