﻿Public Class Employees
    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        OwnerCumin.Show()
        Me.Hide()
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        Form1.Show()
        Me.Hide()

    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        tbempaddress.Clear()
        tbempid.Clear()
        tbempname.Clear()
        tbemprole.Clear()
    End Sub
End Class