﻿Public Class OwnerCumin
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        lbldatetime.Text = Date.Now.ToString("dd-MM-yyyy  hh:mm:ss")
    End Sub

    Private Sub OwnerCumin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
    End Sub

    Private Sub btnfdmode_Click(sender As Object, e As EventArgs) Handles btnfdmode.Click
        AdminPanel.Show()
        Me.Hide()
    End Sub

    Private Sub btnemployee_Click(sender As Object, e As EventArgs) Handles btnemployee.Click
        Employees.Show()
        Me.Hide()
    End Sub

    Private Sub btncredits_Click(sender As Object, e As EventArgs) 
        Credits.Show()
        Me.Hide()
    End Sub

    Private Sub btnlogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        MessageBox.Show("Goodbye Sir Cumin. Until next time.", "Logged out",
 MessageBoxButtons.OK, MessageBoxIcon.Information)
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnentertainment_Click(sender As Object, e As EventArgs) Handles btnentertainment.Click
        Entertainment.Show()
        Me.Hide()
    End Sub
End Class