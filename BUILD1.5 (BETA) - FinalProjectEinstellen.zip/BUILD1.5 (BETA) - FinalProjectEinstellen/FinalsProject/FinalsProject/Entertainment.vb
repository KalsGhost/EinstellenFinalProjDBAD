﻿Public Class Entertainment
    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        OwnerCumin.Show()
        Me.Hide()
    End Sub


End Class