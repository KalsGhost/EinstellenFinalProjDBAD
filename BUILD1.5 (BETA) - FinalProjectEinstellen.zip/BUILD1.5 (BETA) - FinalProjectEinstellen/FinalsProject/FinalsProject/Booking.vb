﻿Public Class Booking
    Private Sub btnokay_Click(sender As Object, e As EventArgs) Handles btnokay.Click
        Me.Close()
        Form1.Close()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Credits.Show()
        Me.Hide()
    End Sub

    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        Form1.Show()
        Me.Hide()

    End Sub




End Class