﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Announcements
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Announcements))
        Me.btnads1 = New System.Windows.Forms.Button()
        Me.btnads2 = New System.Windows.Forms.Button()
        Me.btnads3 = New System.Windows.Forms.Button()
        Me.btnback = New System.Windows.Forms.Button()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.btnads4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnads1
        '
        Me.btnads1.Image = CType(resources.GetObject("btnads1.Image"), System.Drawing.Image)
        Me.btnads1.Location = New System.Drawing.Point(12, 12)
        Me.btnads1.MaximumSize = New System.Drawing.Size(143, 407)
        Me.btnads1.MinimumSize = New System.Drawing.Size(143, 407)
        Me.btnads1.Name = "btnads1"
        Me.btnads1.Size = New System.Drawing.Size(143, 407)
        Me.btnads1.TabIndex = 0
        Me.btnads1.UseVisualStyleBackColor = True
        '
        'btnads2
        '
        Me.btnads2.Image = CType(resources.GetObject("btnads2.Image"), System.Drawing.Image)
        Me.btnads2.Location = New System.Drawing.Point(161, 12)
        Me.btnads2.MaximumSize = New System.Drawing.Size(469, 194)
        Me.btnads2.MinimumSize = New System.Drawing.Size(469, 194)
        Me.btnads2.Name = "btnads2"
        Me.btnads2.Size = New System.Drawing.Size(469, 194)
        Me.btnads2.TabIndex = 1
        Me.btnads2.UseVisualStyleBackColor = True
        '
        'btnads3
        '
        Me.btnads3.Image = CType(resources.GetObject("btnads3.Image"), System.Drawing.Image)
        Me.btnads3.Location = New System.Drawing.Point(161, 225)
        Me.btnads3.MaximumSize = New System.Drawing.Size(469, 194)
        Me.btnads3.MinimumSize = New System.Drawing.Size(469, 194)
        Me.btnads3.Name = "btnads3"
        Me.btnads3.Size = New System.Drawing.Size(469, 194)
        Me.btnads3.TabIndex = 2
        Me.btnads3.UseVisualStyleBackColor = True
        '
        'btnback
        '
        Me.btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnback.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnback.ForeColor = System.Drawing.SystemColors.Highlight
        Me.btnback.Location = New System.Drawing.Point(695, 449)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(80, 29)
        Me.btnback.TabIndex = 3
        Me.btnback.Text = "Back"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnclose
        '
        Me.btnclose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnclose.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnclose.ForeColor = System.Drawing.Color.IndianRed
        Me.btnclose.Location = New System.Drawing.Point(781, 449)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(80, 29)
        Me.btnclose.TabIndex = 4
        Me.btnclose.Text = "Close"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'btnads4
        '
        Me.btnads4.Image = CType(resources.GetObject("btnads4.Image"), System.Drawing.Image)
        Me.btnads4.Location = New System.Drawing.Point(649, 12)
        Me.btnads4.MaximumSize = New System.Drawing.Size(212, 407)
        Me.btnads4.MinimumSize = New System.Drawing.Size(212, 407)
        Me.btnads4.Name = "btnads4"
        Me.btnads4.Size = New System.Drawing.Size(212, 407)
        Me.btnads4.TabIndex = 5
        Me.btnads4.UseVisualStyleBackColor = True
        '
        'Announcements
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(873, 490)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnads4)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.btnads3)
        Me.Controls.Add(Me.btnads2)
        Me.Controls.Add(Me.btnads1)
        Me.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Announcements"
        Me.Text = "Announcements"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnads1 As Button
    Friend WithEvents btnads2 As Button
    Friend WithEvents btnads3 As Button
    Friend WithEvents btnback As Button
    Friend WithEvents btnclose As Button
    Friend WithEvents btnads4 As Button
End Class
